import NextAuth, { DefaultSession } from 'next-auth';

declare module 'next-auth' {
    interface Session {
        user: {
            id: string;
            name?: string | null;
            email?: string | null;
            image?: string | null;
            role?: string; // Role personalizada
        };
    }

    interface User {
        id: string;
        role?: string; // Role do usuário
    }
}

declare module 'next-auth/jwt' {
    interface JWT {
        sub?: string; // ID do usuário
        role?: string; // Role do usuário
    }
}