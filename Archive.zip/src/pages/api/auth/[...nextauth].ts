import NextAuth from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';

export default NextAuth({
    providers: [
        GoogleProvider({
            clientId: process.env.GOOGLE_CLIENT_ID!,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
        }),
    ],
    callbacks: {
        async session({ session, token }) {
            // Adiciona o ID e a role ao objeto session.user
            session.user.id = token.sub || '';
            session.user.role = token.role || 'user'; // Adiciona a role (padrão 'user')
            return session;
        },
        async jwt({ token, user }) {
            // Propaga a role para o token
            if (user) {
                token.role = user.role || 'user';
            }
            return token;
        },
    },
});